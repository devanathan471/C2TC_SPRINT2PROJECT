package com.tnsif.mallshopowner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallshopownerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MallshopownerApplication.class, args);
	}

}
