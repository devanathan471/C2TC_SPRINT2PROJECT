package com.tnsif.mallshopowner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallshopownerApplicationTests {

	@Test
	void contextLoads() {
	}

}
